#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
__author__ = 'top'
date = '16/11/8'
我爱学习,学习使我快乐
'''
'''
套话后的引言
xiansheng : 男士姓名
xiaojie : 女士姓名
'''

model_2 = [
    {
        "model":"今天是%(xiansheng)s先生和%(xiaojie)s女士喜结连理的日子。天作之合。"
    },
    {
        "model":"首先，请允许我代表在座的各位来宾，向二位新人致以真诚的祝福！同时受新郎、新娘委托，向参加今天婚礼的各位来宾表示热烈欢迎和衷心感谢！"
    },
    {
        "model":"%(xiansheng)s先生是单位的业务主干，%(xiaojie)s女士温柔贤惠，今天是你们大喜的日子。"
    },
    {
        "model":"春回大地，万象更新，在这个暖意融融，喜气洋洋的日子里，一对新人%(xiansheng)s先生和%(xiaojie)s小姐甜蜜携手，共同组成新的家庭。"
    },
    {
        "model":"在这浪漫温馨、吉庆祥和的日子，我们欢聚一堂，共同鉴证%(xiansheng)s先生和%(xiaojie)s小姐在此踏上爱情的红地毯，步入温馨的婚姻殿堂。"
    },
    {
        "model":"今天是 %(xiansheng)s先生和%(xiaojie)s小姐新婚大喜之日，两位新人跟随金秋的脚步，踏入红地毯的另一端，从此开始携手走进崭新的生活。"
    },
    {
        "model":"今天我们在这里欢聚一堂，共同祝贺%(xiansheng)s和%(xiaojie)s两位同志的新婚大喜，"
    },
]
