from binkepengyou import xinniangfang as binke_xinniangfang
from binkepengyou import xinlangfang as binke_xinlangfang

from fumu import xinniangfang as fumu_xinniangfang
from fumu import xinlangfang as fumu_xinlangfang

from lingdao import xinniangfang as lingdao_xinniangfang
from lingdao import xinlangfang as lingdao_xinlangfang

from xinlang import all_models as xinlang

from zhenghunren import  all_models as zhenghunren