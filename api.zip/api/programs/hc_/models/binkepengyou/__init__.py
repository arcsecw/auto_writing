#!/usr/bin/env python  
# -*- encoding: utf-8 -*-
'''
__author__ = 'top'
date = '17/1/5'
我爱学习,学习使我快乐
'''
from xinlangfang import all_models as xinlangfang
from xinniangfang import all_models as xinniangfang