#!/usr/bin/env python  
# -*- encoding: utf-8 -*-
'''
__author__ = 'top'
date = '16/12/21'
我爱学习,学习使我快乐
'''
from all_models import all_models