#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
__author__ = 'top'
date = '16/11/8'
我爱学习,学习使我快乐
'''
'''
问候语 套话
zhongwu_or_wanshang :中午 晚上
'''

model_1 = [
    {
      "model":"女士们，先生们，各位领导、各位朋友，大家好！"
    },
    {
      "model":"各位嘉宾："
    },
    {
      "model":"各位来宾，大家好！"
    },
    {
      "model":"各位来宾："
    },
    {
      "model":"各位朋友、各位来宾、各位亲友，先生们、女士们：大家%(zhongwu_or_wanshang)s好！"
    },
    {
      "model":"各位宾朋好友、女士们、先生们：%(zhongwu_or_wanshang)s好！"
    },
    {
      "model":"尊敬的各位嘉宾：大家%(zhongwu_or_wanshang)s好！"
    },
  ]