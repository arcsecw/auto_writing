#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
__author__ = 'top'
date = '16/11/8'
我爱学习,学习使我快乐
'''
'''
问候语 套话
zhongwu_or_wanshang :中午 晚上
'''

model_5 = [
    {
      "model":"谢谢大家"
    },
    {
      "model":"最后，请大家与我们一起分享着幸福快乐的夜晚。祝大家万事如意、梦想事成。"
    },
    {
      "model":"最后，祝各位今晚用餐愉快，再次感谢各位的光临！"
    },
  ]