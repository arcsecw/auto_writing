#!/usr/bin/env python  
# -*- encoding: utf-8 -*-
'''
__author__ = 'top'
date = '16/12/21'
我爱学习,学习使我快乐
'''
from wanbei import all_models as man_wanbei
from zhuchi import all_models as man_zhuchi