from man import man_wanbei
from man import man_zhuchi
from woman import woman_wanbei
from woman import woman_zhuchi