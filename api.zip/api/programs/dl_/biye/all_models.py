#!/usr/bin/env python
# -*- encoding: utf-8 -*-
'''
__author__ = 'top'
date = '16/11/8'
我爱学习,学习使我快乐
'''
from model_1 import model_1
from model_2 import model_2
from model_3 import model_3
from model_4 import model_4
all_models = [
    {
        "model":model_1,
        "num":1
    },
    {
        "model":model_2,
        "num":1
    },
    {
        "model":model_3,
        "num":1
    },
    {
        "model":model_4,
        "num":1
    }
]
